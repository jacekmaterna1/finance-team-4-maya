# Competitor battlecards

Last updated: October 2025. Owner: VP Marketing.

## Billwright

Enterprise billing and revenue platform for big firms (200+ seats). Powerful, expensive, slow to stand up. Usually shows up when IT or the CFO's office is running the eval. Last updated Oct 2025.

- **Who they sell to:** Large consultancies, engineering firms and multi-office law firms, typically 150 to 2,000 billable staff, multiple legal entities, a finance team with a dedicated systems person. Shows up in our Enterprise deals, almost never in Core or Growth.
- **Pricing (as we understand it):** As of Oct 2025: list is about $140/seat/month on a 3-year term, 25-seat minimum. Platform fee is not published; reps have quoted $30k-$45k/yr. Implementation is done through their services team or a partner, typically $35k-$60k, and we've heard of a $90k SOW for a 6-entity firm. Usually 5-15% annual uplift written into renewals. They discount hard in Q4 (their fiscal year ends Dec 31).

**Strengths**

- Deep multi-entity and multi-currency, including intercompany billing. Better than ours today for firms with 5+ entities across countries.
- Revenue recognition and WIP reporting that controllers like. Their audit trail is genuinely good.
- Mature, well-documented API and a big partner ecosystem. Procurement sees them as the safe choice.
- Big-firm logos. They will put an exec reference on the phone within a day.

**Weaknesses**

- Price. At 80 seats, Billwright is roughly $134k/yr before implementation. Ledgerline Enterprise is about $96k all in ($88 x 80 x 12 + $12k), plus an $8k one-time implementation.
- Implementations run 4-8 months. Ours average 6-8 weeks on Enterprise. Ask the prospect if they can wait until next fiscal year to send their first invoice.
- The UI is dated and built for finance staff, not partners. Partners approving invoices on their phone is painful. Their client portal is an add-on and looks like it.
- QuickBooks Online and Xero support is shallow. They expect a big ERP behind them, so mid-size firms on QBO end up with CSV exports.

**How we win:** Win on time-to-value and total cost. Get the buyer to put the full 3-year number side by side, including implementation and the uplift clauses. Demo partner approvals and the client portal live, because that's where Billwright looks old. Lean on the named account manager and one-hour support response: Billwright support is ticket-based unless you pay for their premium tier. Best fit for us is 40-150 seats, 1-3 entities, on QBO or Xero.

**How we lose:** We lose when the firm has lots of entities and currencies, a controller who needs rev rec inside the billing tool, or an IT team that wants the 'nobody got fired for buying it' option. If they're above ~250 seats with 5+ entities, qualify hard. We have lost three of those in 2025 and we shouldn't burn SE time chasing them.

## Retainly

Cheap, simple invoicing and retainer tool for solo practitioners and very small firms. Nice UI, very little depth.

- **Who they sell to:** Freelancers, 1-10 person agencies, solo attorneys and small bookkeeping practices. Usually the owner buys it with a credit card in an afternoon. We see them when a firm that started on Retainly hits 10-20 people and starts feeling the limits.
- **Pricing (as we understand it):** As of Oct 2025: Starter $49/month flat for up to 3 users, then $19/user/month on Team (monthly or annual, about 15% off annual). No implementation fee and no contract. Card processing goes through Stripe at Stripe's standard rates plus a 0.5% Retainly platform fee on payments (this is buried in their terms; point it out).

**Strengths**

- Price. For a 4-person firm it's about $76/month against $188/month for us on Core. We won't win that on cost.
- Very fast setup. People are sending invoices the same day, no call needed.
- Clean, simple UI that owners like. Recurring retainer invoices are easy for basic cases.
- Good self-serve help content and a decent template library.

**Weaknesses**

- No milestone billing, no approval rules, no scheduled reports. Once a firm has partners or project managers who need to sign off on invoices, they hit a wall.
- Payments are Stripe card/ACH only, plus that 0.5% platform fee. On $2m/yr collected, that's $10k they're paying Retainly on top of processing.
- QuickBooks Online sync only, and it's one-way. No Xero. Customers tell us reconciliation is manual and breaks on partial payments.
- Email-only support, business hours, no phone. Nothing like an account manager at any size.

**How we win:** Target firms of roughly 10-40 people who are outgrowing Retainly. Discovery questions: Who approves invoices before they go out? How do you bill fixed-fee projects in phases? How long does month-end reconciliation take? Do the math on the 0.5% platform fee. At their volume it often pays for most of the gap to our Core or Growth. Offer to migrate their client list and open retainers; we have a Retainly import script, so ask CS.

**How we lose:** Under ~8 seats with a price-sensitive owner and simple billing, we lose and that's fine. Don't discount Core to chase it. We also lose when the champion loves Retainly's UI and nobody else at the firm cares about approvals yet. Plant the seed, set a 6-month follow-up, and move on.

## Practico

All-in-one practice management suite (time tracking, projects, resourcing, CRM-lite) where billing is one module of many. Wide, not deep on billing.

- **Who they sell to:** 20-200 person agencies, architecture practices and consultancies that want one system for everything and are often replacing a pile of spreadsheets. The buyer is usually the COO or managing partner, not finance.
- **Pricing (as we understand it):** As of Oct 2025: Essentials $39/user/month (time, projects, basic invoicing), Professional $62/user/month (adds resourcing, budgets, retainers, QBO/Xero sync), Premium $85/user/month (adds advanced approvals, custom reports, SSO). Annual only. Onboarding is $3k-$15k depending on tier and data migration. Key point: they charge every user, including people who only log time. Billing customers on Ledgerline usually need far fewer seats.

**Strengths**

- One system. Time, projects and billing in one place is a strong pitch to an ops-minded buyer who's tired of integrations.
- Resourcing and capacity planning are good, honestly better than anything in our space.
- Strong in agencies and architecture. Lots of peer references and a big user community.
- Invoices pull straight from time entries without a sync, so WIP is visible in real time.

**Weaknesses**

- Billing is an afterthought. Milestone billing is clunky (manual percentages), no partial-payment handling worth the name, and the client portal is basic, with no online approval of invoices by the client.
- Payment collection relies on a Stripe connection, with no native bank transfer reconciliation. Finance teams end up doing collections in spreadsheets.
- Every timekeeper is a paid seat. A 60-person firm pays for 60 Practico seats when only ~8-12 people actually touch billing.
- It's all-or-nothing. If the firm likes its existing time tracking or project tool, they have to rip it out to get Practico billing.

**How we win:** Win with the finance buyer (CFO, controller, billing manager) and when the firm already has time tracking or project management it's happy with. Run the seat math: 60 people on Practico Professional is about $44.6k/yr; 10 billing seats on our Growth is $8.2k/yr. Demo milestone billing, approval rules and the client portal back to back, because that's where Practico is weakest. Ask how they chase overdue invoices today.

**How we lose:** We lose when the COO wants one system and finance doesn't have a strong voice in the decision. We also lose when the firm has no time tracking at all and needs to buy something anyway. If ops owns the deal, get to finance early or expect to lose.

## Tallyfirm

UK-based billing tool built around Xero. Very strong with UK accounting, law and consulting practices; weak outside the UK.

- **Who they sell to:** UK professional services firms on Xero, typically 5-80 staff: accountancy practices, solicitors, small consultancies. We run into them with UK-only firms and with US firms that have a UK office.
- **Pricing (as we understand it):** As of Oct 2025: Standard £32/user/month, Plus £45/user/month (adds retainers, workflow approvals, reporting), Practice £60/user/month (multi-office, API). Monthly or annual (2 months free on annual). No implementation fee on Standard; £1,500 onboarding package on Plus and up. They started quoting USD in 2025 at about $42/$59/$79, but US pricing seems to be negotiable.

**Strengths**

- The deepest Xero integration in the market, two-way and near real time, including tracking categories. Xero partners recommend them a lot.
- UK-specific features: Direct Debit collection, VAT handling, Making Tax Digital-friendly reporting, client money considerations for law firms.
- Strong reputation and referral network through UK accountancy practices.
- UK business hours phone support, and people like it.

**Weaknesses**

- QuickBooks Online integration is new (launched early 2025), one-way, and customers report sync errors. Most of our US base is on QBO.
- US payments are thin: card only through Stripe, no US ACH bank transfer reconciliation as of Oct 2025.
- Support is UK hours only. US customers get email responses the next morning.
- No real multi-entity across currencies. Firms with US and UK entities end up running two Tallyfirm accounts.

**How we win:** Win any US-headquartered firm, especially on QBO, and multi-entity firms with US and UK operations (Enterprise multi-entity handles both). Show our US bank transfer collection and the QBO sync live. For US firms with a UK office, ask who supports the US team at 2pm Central. Our Xero integration is solid for standard use cases, so don't concede Xero just because Tallyfirm is in the deal.

**How we lose:** UK-only firms on Xero, particularly accountancy practices and solicitors, will mostly pick Tallyfirm. They have Direct Debit, VAT specifics and the partner referrals, and we don't have a UK presence. Don't spend heavily on these unless there's a US entity involved. Flag them to product, because we keep getting the Direct Debit request.

## FeeLedger

Newer billing product (founded 2023) that leads with AI: auto-drafted invoices, an AI collections agent, and natural-language reporting. Great demo, thin product underneath.

- **Who they sell to:** Tech-forward agencies and consultancies, 10-100 staff, often with a younger managing partner or an exec who has been told to 'do something with AI.' Increasingly showing up in our Growth-tier deals in 2025.
- **Pricing (as we understand it):** As of Oct 2025: Pro $59/seat/month, Scale $79/seat/month (adds approvals, multi-entity beta, API). The AI features run on a credit system. Pro includes 500 AI credits/month, extra packs are $150 for 1,000, and heavy collections-agent use burns through credits fast. Monthly or annual, no implementation fee, but they've been offering 3 months free to win deals off us.

**Strengths**

- Impressive demo. Invoice drafts generated from time entries and project notes, with narrative line descriptions, land well with partners who hate writing invoice descriptions.
- AI collections agent that sends and follows up on overdue reminders in a tone you choose. Prospects love it in a demo.
- 'Ask your data' reporting (e.g., 'which clients are over 60 days?'). Easy for non-finance people to use.
- Modern UI, fast product releases, aggressive pricing and promos.

**Weaknesses**

- Young product with a small customer base (we think under 100 paying firms). Few references and no track record at scale.
- Accuracy concerns. Two prospects told us drafted invoices pulled the wrong rates and descriptions, and an auto-sent collections email went to a client who had already paid. Ask about guardrails.
- Retainers and milestone billing are basic. Approval rules exist only on Scale and are simple (single approver, no thresholds).
- Security and compliance are still catching up. SOC 2 Type I only as of Oct 2025, SSO is in beta, and they're vague about how client data is used by the AI.

**How we win:** Shift the conversation from the demo to control and trust. Who approves an AI-drafted invoice before it goes to a client? What happens if the collections agent emails the wrong person? Show our approval rules with dollar thresholds and the audit trail. Bring the compliance questionnaire early; their Type I and SSO beta hurt them with any firm that has a security review. Offer customer references with 3+ years on Ledgerline. Point out that the credit model makes their real cost unpredictable. Don't trash AI. Say we're adding assistive features carefully, with approvals built in.

**How we lose:** We lose when an exec has mandated 'AI' and the demo is the decision, when the firm is small enough that nobody runs a security review, or when the 3-months-free promo closes it before finance gets involved. If a partner is excited about AI invoice drafts in the first call, get finance and whoever owns client relationships into the second call quickly.
