# Ledgerline data room

Ledgerline is a fictional B2B software company. Everything here was invented for the Scaleworks AI Operator Challenge: no real company, person or customer is described. Use any of it, in any way, to build your tool.

- **As-of date:** 2026-10-31. Treat that as today.
- **History:** January 2023 to October 2026.
- **Currency:** US dollars throughout. Amounts exclude sales tax.
- **Start with:** `docs/company_overview.md`, then `docs/processes.md`.

## Files

### Documents

| File | Size | What it is |
|---|---|---|
| `docs/templates/collections.md` | document | Collections reminders: the 4 templates in use today. |
| `docs/templates/nurture.md` | document | Lead nurture sequences: the 9 templates in use today. |
| `docs/templates/sdr.md` | document | Sales development replies: the 3 templates in use today. |
| `docs/templates/support_macro.md` | document | Support macros: the 4 templates in use today. |
| `docs/templates/renewal.md` | document | Renewal emails: the 2 templates in use today. |
| `docs/billing_engine_rewrite_2026.md` | document | What changed in the product when the billing engine was replaced in March 2026. |
| `docs/company_overview.md` | document | What Ledgerline sells, who to, and the headline numbers. |
| `docs/org_chart.md` | document | Who works where and who they report to. |
| `docs/pricing_and_packaging.md` | document | The internal price list, plan contents and discount rules. |
| `docs/tool_stack.md` | document | Which tools the company uses, for what, and the gaps between them. |
| `docs/icp.md` | document | The ideal customer profile document, as last written by marketing. |
| `docs/sales_playbook.md` | document | How inbound leads are meant to be handled and routed, and the rules for replies. |
| `docs/sla_policy.md` | document | Support response commitments and the rules for sensitive tickets. |
| `docs/collections_policy.md` | document | The rules finance follows when chasing overdue invoices. |
| `docs/board_update_2026_q3.md` | document | The most recent board update, with the quarter's numbers and the leadership's stated concerns. |
| `docs/processes.md` | document | The 31 business processes you can choose from, with owner, volume, steps and pain. |
| `docs/process_maps.md` | document | Flow diagrams for collections, cash application, inbound leads, ticket triage and renewals. |

### Customers

| File | Size | What it is |
|---|---|---|
| `customers/customers.csv` | 508 rows | Every customer, active and churned, with plan, size, contract value, renewal date and owner. |
| `customers/contacts.csv` | 967 rows | Named contacts at each customer and their role. |
| `customers/contracts.csv` | 1,757 rows | One row per annual contract term. The source of ARR: every invoice and every ARR movement comes from these. |

### Finance

| File | Size | What it is |
|---|---|---|
| `finance/payroll_monthly.csv` | 368 rows | Monthly payroll cost by department. Ties to the payroll lines in the P&L. |
| `finance/arr_movements_monthly.csv` | 46 rows | Monthly ARR bridge: opening, new, expansion, contraction, churn, closing. |
| `finance/invoices.csv` | 6,062 rows | Every invoice since the contract terms in force at 1 January 2023, with status as recorded in the ledger at 31 October 2026. |
| `finance/payments.csv` | 5,808 rows | Every receipt from the bank and Stripe. Receipts not yet matched to an invoice have no invoice id. |
| `finance/ar_aging.csv` | 117 rows | Unpaid invoices at 31 October 2026, aged by days past due. The same report finance exports from QuickBooks. |
| `finance/pnl_monthly.csv` | 966 rows | Monthly management P&L from January 2023, down to EBITDA. |
| `finance/balance_sheet_monthly.csv` | 46 rows | Month-end balance sheet and cash movement. |
| `finance/vendor_bills.csv` | 1,651 rows | Every vendor bill. Ties to the non-payroll cost lines in the P&L. |

### Sales

| File | Size | What it is |
|---|---|---|
| `sales/opportunities.csv` | 2,176 rows | HubSpot deals: new business, renewals and open pipeline, with owner, stage, amount and loss reason. |
| `sales/leads.csv` | 14,573 rows | Every lead since January 2023. Times are US Central. Form message text is kept for leads from 1 September 2026 only. |
| `sales/deal_notes.csv` | 186 rows | Call notes and email threads for 45 recent deals: won, lost and open. Join to opportunities.csv. |
| `sales/proposals/proposal_OPP-42084.md` | document | The proposal sent to Yates & Prior CPAs before they signed. |
| `sales/proposals/proposal_OPP-41999.md` | document | The proposal sent to Hale & Ruiz Agency before they signed. |
| `sales/proposals/proposal_OPP-42083.md` | document | The proposal sent to Calloway & Voss Advisory before they signed. |
| `sales/proposals/proposal_OPP-42071.md` | document | The proposal sent to Achebe + Pemberton Architects before they signed. |
| `sales/proposals/proposal_OPP-42065.md` | document | The proposal sent to Rosales Engineering before they signed. |
| `sales/proposals/proposal_OPP-42035.md` | document | The proposal sent to Brandt Strategy before they signed. |
| `sales/proposals/proposal_OPP-41952.md` | document | The proposal sent to Crane Strategy before they signed. |
| `sales/proposals/proposal_OPP-41988.md` | document | The proposal sent to Nair & Hale Agency before they signed. |

### Marketing

| File | Size | What it is |
|---|---|---|
| `marketing/marketing_spend_monthly.csv` | 230 rows | Marketing programme spend by channel and month. Ties to vendor bills. |
| `marketing/web_funnel_monthly.csv` | 414 rows | Monthly funnel by channel, from sessions to customers won. |
| `marketing/competitor_battlecards.md` | document | Sales battlecards for the five competitors, last updated October 2025. |
| `marketing/reviews.csv` | 48 rows | Reviews of Ledgerline and its competitors from a software review site, January to October 2026. |
| `marketing/blog_posts.csv` | 68 rows | Every blog post with traffic and leads. Full text is included for eight of them. |

### Support

| File | Size | What it is |
|---|---|---|
| `support/tickets.csv` | 1,041 rows | Every Zendesk ticket from 1 July to 31 October 2026, with full text. Times are US Central. Category is as tagged by the agent. |
| `support/tickets_monthly.csv` | 46 rows | Monthly ticket volumes, response time, SLA and CSAT since January 2023. |
| `support/help_center_articles.csv` | 120 rows | The 120 help centre articles in full, with last-updated date and usage. |
| `support/nps_responses.csv` | 820 rows | Quarterly NPS survey responses since March 2025. |

### Product

| File | Size | What it is |
|---|---|---|
| `product/usage_monthly.csv` | 6,955 rows | Product usage per customer per month for the last 18 months. |

### People

| File | Size | What it is |
|---|---|---|
| `people/employees.csv` | 52 rows | Everyone employed since 2018, with title, manager, dates and current base salary (pay rose about 4% a year). |

## How the files join

- `customer_id` links customers, contacts, contracts, invoices, tickets, usage, NPS responses and won opportunities.
- `invoice_id` links invoices to payments and to the AR aging report.
- `opportunity_id` links a lead to the opportunity it became.
- Contracts are the source of ARR. Each contract term produces its invoices; the ARR movements file is the monthly sum of contract changes.
- Vendor bills and payroll add up to the cost lines in the P&L.

## How real is it

The files reconcile with each other the way a real company's do, including the places where a real company's systems disagree. Records are sometimes late, mis-tagged or missing. That is deliberate: it is what you would find on day one.

Some history is thinner than the rest, as it would be in practice: full ticket text is kept for the last four months, lead form messages for the last two, and product usage for the last 18 months.
