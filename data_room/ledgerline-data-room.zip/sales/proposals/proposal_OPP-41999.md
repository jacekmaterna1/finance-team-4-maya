# Proposal for Hale & Ruiz Agency

Prepared by Leila Haddad, Ledgerline · 2026-10-01 · Valid for 30 days · Opportunity OPP-41999

## What you asked for

Billing and payments for a marketing or creative agency of about 24 people, with 17 people who raise or approve invoices.

## What we propose

| Item | Detail | Annual cost |
|---|---|---|
| Ledgerline Growth | 17 seats at $68 per seat per month | $13,872 |
| **Annual subscription** | | **$13,872** |
| Implementation (one-off) | Data import, configuration, training | $2,500 |

## Terms

- 12-month term from 2026-10-16, renewing annually. Billed annually in advance, by bank transfer (ACH).
- Payment due 30 days from invoice.
- Seats can be added at any renewal. Prices are from the current price list and exclude sales tax.

## Next steps

1. Sign the order form.
2. Kick-off call with your implementation specialist within five working days.
3. Go live in about six weeks.
