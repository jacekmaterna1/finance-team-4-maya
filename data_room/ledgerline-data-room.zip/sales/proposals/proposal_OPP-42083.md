# Proposal for Calloway & Voss Advisory

Prepared by Leila Haddad, Ledgerline · 2026-09-28 · Valid for 30 days · Opportunity OPP-42083

## What you asked for

Billing and payments for a management consultancy of about 20 people, with 12 people who raise or approve invoices.

## What we propose

| Item | Detail | Annual cost |
|---|---|---|
| Ledgerline Core | 12 seats at $47 per seat per month | $6,768 |
| **Annual subscription** | | **$6,768** |
| Implementation (one-off) | Self-serve with guided setup | Included |

## Terms

- 12-month term from 2026-10-08, renewing annually. Billed monthly, by card.
- Payment due 30 days from invoice.
- Seats can be added at any renewal. Prices are from the current price list and exclude sales tax.

## Next steps

1. Sign the order form.
2. Kick-off call with your implementation specialist within five working days.
3. Go live in about six weeks.
