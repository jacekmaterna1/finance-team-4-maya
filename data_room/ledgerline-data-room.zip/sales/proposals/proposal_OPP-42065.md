# Proposal for Rosales Engineering

Prepared by Nick Ferraro, Ledgerline · 2026-08-31 · Valid for 30 days · Opportunity OPP-42065

## What you asked for

Billing and payments for a engineering consultancy of about 28 people, with 20 people who raise or approve invoices.

## What we propose

| Item | Detail | Annual cost |
|---|---|---|
| Ledgerline Growth | 20 seats at $68 per seat per month | $16,320 |
| **Annual subscription** | | **$16,320** |
| Implementation (one-off) | Data import, configuration, training | $2,500 |

## Terms

- 12-month term from 2026-09-24, renewing annually. Billed annually in advance, by wire.
- Payment due 30 days from invoice.
- Seats can be added at any renewal. Prices are from the current price list and exclude sales tax.

## Next steps

1. Sign the order form.
2. Kick-off call with your implementation specialist within five working days.
3. Go live in about six weeks.
