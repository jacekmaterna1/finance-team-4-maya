# Proposal for Achebe + Pemberton Architects

Prepared by Nick Ferraro, Ledgerline · 2026-09-21 · Valid for 30 days · Opportunity OPP-42071

## What you asked for

Billing and payments for a architecture practice of about 189 people, with 53 people who raise or approve invoices.

## What we propose

| Item | Detail | Annual cost |
|---|---|---|
| Ledgerline Enterprise | 53 seats at $88 per seat per month | $55,968 |
| Enterprise platform fee | Multi-entity, single sign-on, API access | $12,000 |
| **Annual subscription** | | **$67,968** |
| Implementation (one-off) | Data import, configuration, training | $8,000 |

## Terms

- 12-month term from 2026-10-05, renewing annually. Billed annually in advance, by wire.
- Payment due 30 days from invoice.
- Seats can be added at any renewal. Prices are from the current price list and exclude sales tax.

## Next steps

1. Sign the order form.
2. Kick-off call with your implementation specialist within five working days.
3. Go live in about six weeks.
