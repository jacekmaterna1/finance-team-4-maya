# Process maps

Flow diagrams for five of the processes, in Mermaid syntax. Paste a block into any Mermaid viewer to render it.

## FIN-1 Collections

```mermaid
flowchart TD
  A[Export AR aging from QuickBooks] --> B{Overdue?}
  B -- no --> Z[No action]
  B -- yes --> C[Ask account manager and support about open issues]
  C --> D{Dispute or escalation?}
  D -- yes --> E[Hold. Account manager decides when to resume]
  D -- no --> F{Top 50 account?}
  F -- yes --> G[VP Finance or AR Specialist writes personally]
  F -- no --> H[Reminder email from template]
  H --> I{Paid within 14 days?}
  G --> I
  I -- no --> J[Phone call, offer payment plan]
  J --> K{Still unpaid at 90 days?}
  K -- yes --> L[Escalate to VP Finance]
```

## FIN-2 Cash application

```mermaid
flowchart TD
  A[Bank and Stripe receipts] --> B{Card via Stripe?}
  B -- yes --> C[Matched automatically]
  B -- no --> D[Read memo, payer name and amount]
  D --> E{One open invoice matches?}
  E -- yes --> F[Apply payment in QuickBooks]
  E -- no --> G[Email customer to ask which invoice]
  G --> F
```

## SAL-1 Inbound lead handling

```mermaid
flowchart TD
  A[Form fill lands in HubSpot] --> B[SDR reads it]
  B --> C{Existing customer?}
  C -- yes --> D[Pass to account manager or support]
  C -- no --> E{Real prospect?}
  E -- no --> F[Disqualify with reason]
  E -- yes --> G{Fits the ICP?}
  G -- no --> H[Nurture]
  G -- yes --> I{Under 200 staff?}
  I -- yes --> J[Nick or Leila]
  I -- no --> K[Owen or Grace]
  J --> L[Reply and book meeting]
  K --> L
```

## SUP-1 Ticket triage

```mermaid
flowchart TD
  A[New ticket in Zendesk] --> B[Agent reads and tags]
  B --> C{Legal, cancellation or chargeback?}
  C -- yes --> D[Head of Support within one hour]
  C -- no --> E{Enterprise account?}
  E -- yes --> F[One-hour response queue]
  E -- no --> G[Standard queue]
  F --> H{Category}
  G --> H
  H -- billing --> I[Billing specialist]
  H -- bug --> J[Technical specialist, raise Jira]
  H -- other --> K[Generalist]
```

## CS-2 Renewal preparation

```mermaid
flowchart TD
  A[Renewals due in 90 days] --> B[Account manager checks usage, tickets, unpaid invoices]
  B --> C{At risk?}
  C -- yes --> D[Save plan, call the sponsor]
  C -- no --> E{Room to expand?}
  E -- yes --> F[Propose more seats or a higher plan]
  E -- no --> G[Renew at current terms and new price list]
  D --> H[Agreed terms to finance]
  F --> H
  G --> H
  H --> I[Finance updates Stripe and raises the invoice]
```
