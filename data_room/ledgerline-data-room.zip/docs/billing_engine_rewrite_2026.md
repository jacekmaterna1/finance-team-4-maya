# Billing engine rewrite: what changed on 16 March 2026

Release note from Product & Engineering. Sent to all staff and summarised to customers by email.

| | Before 16 March 2026 | Now |
|---|---|---|
| Proration | Every month treated as 30 days | By the exact number of days in the billing period |
| Rounding | Total calculated unrounded, then rounded once | Each line rounded to the cent; the total is the sum of the lines |
| Failed card payments | One retry after three days, no email | Three retries over seven days, with an email to the client after each |
| Editing a sent invoice | Void it and create a new one | Creates a new version and an automatic credit note for the difference |
| Changing a retainer mid-cycle | Takes effect from the next cycle | Takes effect immediately, with a prorated adjustment invoice |
| Seat and plan changes | Billed at once as a separate invoice | Prorated to the day and added to the next invoice |
| Where the settings are | Billing > Preferences | Settings > Billing engine |
| Due dates | Calculated in US Central time | Calculated in the firm's own time zone |

Help centre articles, support macros and email templates written before this date describe the old behaviour unless someone has updated them since.
