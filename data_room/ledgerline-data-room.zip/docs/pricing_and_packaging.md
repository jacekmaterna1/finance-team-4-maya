# Pricing and packaging (internal price list)

This is the list sales quotes from. The public pricing page on the website still shows 2024 prices and has not been updated.

| Plan | Per seat per month, from 1 Jan 2025 | Before 2025 | Annual platform fee | Minimum seats |
|---|---|---|---|---|
| Core | $47 | $45 | none | 8 |
| Growth | $68 | $65 | none | 12 |
| Enterprise | $88 | $85 | $12,000 | 20 |

- All contracts are annual and renew on the anniversary of signing. Customers choose to be billed annually, quarterly or monthly.
- Seats can be added at renewal. Reductions are allowed at renewal only.
- Implementation fee for new customers: none on Core, $2,500 on Growth, $8,000 on Enterprise.
- Existing customers moved to the 2025 prices at their first renewal after 1 January 2025.

## What each plan includes

- **Core**: invoicing, payments, client portal, one accounting integration.
- **Growth**: everything in Core, plus retainers, milestone billing, approval rules and scheduled reports.
- **Enterprise**: everything in Growth, plus multi-entity, single sign-on, API access, a named account manager and a one-hour first response commitment.

## Discounting

Account executives may discount up to 10% on a first-year contract. Anything more needs the Head of Sales. Multi-year discounts are not offered. No discount is ever promised in writing before approval.
