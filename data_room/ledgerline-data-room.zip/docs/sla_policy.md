# Support SLA policy

| | Standard (Core and Growth) | Enterprise |
|---|---|---|
| First response | 4 business hours | 1 business hour |
| Coverage | 8am to 6pm Central, Monday to Friday | Same |

The Enterprise commitment is in the customer contract.

## Handling rules

- Tickets that mention legal action, a regulator, a chargeback or cancellation go to the Head of Support within one hour.
- No reply goes out unreviewed by a person on anything involving money, data loss or an Enterprise account.
- How-to questions with a matching, current help article may be answered with the article.
- Tickets often contain card fragments, bank details and customers' own client lists. Ticket content must not be sent to a new vendor without a data processing agreement approved by legal.

## Reporting

First response time and CSAT are reported to the COO each week. The CSAT floor agreed with the COO is 84%.
