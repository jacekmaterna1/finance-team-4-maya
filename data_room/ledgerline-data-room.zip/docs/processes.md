# Business processes at Ledgerline

These are 31 jobs people at Ledgerline do today, as described by the people who do them. Hours are their own estimates. You may pick one, combine several, or propose something that is not on this list.

## Finance

### FIN-1: Collections and payment reminders

- **Owner:** AR Specialist
- **How often:** Daily
- **Volume:** About 450 invoices a month; 60 to 110 overdue at any time
- **Time spent:** about 16 hours a week across the team
- **Systems:** QuickBooks Online, Stripe, Gmail, Google Sheets

**Steps today**

1. Export the AR aging report from QuickBooks
2. Check each overdue account for an open dispute or support escalation by asking around
3. Write reminder emails by hand from a few saved templates
4. Phone the largest overdue accounts
5. Agree payment plans and log them in a spreadsheet
6. Escalate stuck accounts to the VP Finance

**Where it hurts:** Reminders go out late and inconsistently. Finance cannot see support tickets, so customers with an open complaint get chased. Failed card payments are rarely followed up.

**Related files:** `finance/invoices.csv`, `finance/payments.csv`, `finance/ar_aging.csv`, `support/tickets.csv`, `customers/customers.csv`, `docs/collections_policy.md`, `docs/templates/collections.md`

### FIN-2: Cash application

- **Owner:** Staff Accountant
- **How often:** Daily
- **Volume:** About 430 payments a month; a third arrive by wire or cheque with a free-text memo
- **Time spent:** about 7 hours a week across the team
- **Systems:** QuickBooks Online, Stripe, Bank portal

**Steps today**

1. Download the bank and Stripe activity
2. Match each receipt to an open invoice using the memo, payer name and amount
3. Chase the customer when a payment cannot be matched
4. Mark the invoice paid in QuickBooks

**Where it hurts:** Matching lags three to five days, so invoices look unpaid when the money has arrived, and customers have been chased for invoices they already paid.

**Related files:** `finance/payments.csv`, `finance/invoices.csv`, `customers/customers.csv`

### FIN-3: Month-end close and management accounts

- **Owner:** VP Finance
- **How often:** Monthly
- **Volume:** One close a month, currently eight working days
- **Time spent:** about 14 hours a week across the team
- **Systems:** QuickBooks Online, Google Sheets

**Steps today**

1. Reconcile bank, Stripe and AR
2. Post revenue recognition and deferred revenue from the billing schedule
3. Accrue commissions and vendor bills
4. Build the P&L and balance sheet
5. Write variance commentary for the CEO

**Where it hurts:** The close takes eight working days and the commentary is written from scratch each month. Variances are explained by memory.

**Related files:** `finance/pnl_monthly.csv`, `finance/balance_sheet_monthly.csv`, `finance/vendor_bills.csv`, `finance/payroll_monthly.csv`, `finance/invoices.csv`

### FIN-4: Board and investor KPI pack

- **Owner:** FP&A Analyst
- **How often:** Quarterly, with a monthly flash
- **Volume:** One pack a quarter, about 25 metrics
- **Time spent:** about 6 hours a week across the team
- **Systems:** QuickBooks Online, HubSpot, Zendesk, Google Slides

**Steps today**

1. Pull ARR movements, churn and retention from billing data
2. Pull pipeline and funnel numbers from HubSpot
3. Pull support and CSAT numbers from Zendesk
4. Assemble the tables and charts
5. Draft the narrative with the CEO and COO

**Where it hurts:** Numbers are pulled by hand from four systems and rarely agree first time. Definitions drift between quarters.

**Related files:** `finance/arr_movements_monthly.csv`, `customers/contracts.csv`, `sales/opportunities.csv`, `support/tickets_monthly.csv`, `docs/board_update_2026_q3.md`

### FIN-5: Vendor bills and software spend review

- **Owner:** Staff Accountant
- **How often:** Weekly bills, quarterly review
- **Volume:** About 45 vendor bills a month
- **Time spent:** about 5 hours a week across the team
- **Systems:** QuickBooks Online, Gmail, Corporate card portal

**Steps today**

1. Collect bills from email and card statements
2. Code each to a category and department
3. Get approval from the budget owner
4. Pay and file
5. Once a quarter, list software subscriptions and ask owners whether they are still used

**Where it hurts:** Nobody owns the software list. Tools overlap, some are no longer used, and renewals are noticed after they have gone through.

**Related files:** `finance/vendor_bills.csv`, `docs/tool_stack.md`, `people/employees.csv`

### FIN-6: Renewal invoicing and billing changes

- **Owner:** AR Specialist
- **How often:** Weekly
- **Volume:** 30 to 40 renewals a month, plus seat changes
- **Time spent:** about 6 hours a week across the team
- **Systems:** Stripe, HubSpot, QuickBooks Online

**Steps today**

1. Get the renewal terms from the account manager
2. Update seats, plan and price in Stripe
3. Raise the invoice and check it against the contract
4. Send it to the billing contact on file
5. Fix and reissue when the customer queries it

**Where it hurts:** Seat counts, price changes and billing contacts are wrong often enough to cause disputes. Each error delays payment.

**Related files:** `customers/contracts.csv`, `customers/contacts.csv`, `finance/invoices.csv`, `docs/pricing_and_packaging.md`, `support/tickets.csv`

### FIN-7: Revenue and cash forecast

- **Owner:** FP&A Analyst
- **How often:** Monthly
- **Volume:** One rolling 12-month forecast
- **Time spent:** about 5 hours a week across the team
- **Systems:** Google Sheets, HubSpot, QuickBooks Online

**Steps today**

1. Roll forward the renewal schedule
2. Estimate churn and expansion by asking CS
3. Add expected new business from the sales forecast
4. Model collections timing
5. Compare last month's forecast to actuals

**Where it hurts:** Churn and collections assumptions are guesses, and the forecast has missed in both directions.

**Related files:** `customers/contracts.csv`, `finance/arr_movements_monthly.csv`, `finance/payments.csv`, `sales/opportunities.csv`, `product/usage_monthly.csv`

## Sales

### SAL-1: Inbound lead qualification and routing

- **Owner:** SDR
- **How often:** Daily
- **Volume:** About 270 form fills a month
- **Time spent:** about 22 hours a week across the team
- **Systems:** HubSpot, Slack, HubSpot Meetings

**Steps today**

1. Read each form fill
2. Look up the company by hand to judge size and fit
3. Check whether they are already a customer
4. Reply and book a call, or disqualify
5. Assign to an account executive by company size

**Where it hurts:** Median first response is most of a day. Existing customers, students and vendors get sales emails. Good leads that arrive late in the day wait until tomorrow.

**Related files:** `sales/leads.csv`, `customers/customers.csv`, `docs/icp.md`, `docs/sales_playbook.md`, `docs/templates/sdr.md`

### SAL-2: Outbound prospecting

- **Owner:** Account Executives
- **How often:** Weekly
- **Volume:** Roughly 150 new prospects contacted a week across four AEs
- **Time spent:** about 20 hours a week across the team
- **Systems:** HubSpot, ZoomInfo, Apollo, LinkedIn

**Steps today**

1. Build a target list by industry and size
2. Research each firm
3. Write a first email and two follow-ups
4. Log activity in HubSpot

**Where it hurts:** Research is shallow, emails are generic, and outbound produces few meetings for the time spent.

**Related files:** `sales/leads.csv`, `sales/opportunities.csv`, `customers/customers.csv`, `docs/icp.md`, `sales/deal_notes.csv`

### SAL-3: Demo preparation and account research

- **Owner:** Account Executives
- **How often:** Per meeting
- **Volume:** About 40 first meetings a month
- **Time spent:** about 10 hours a week across the team
- **Systems:** HubSpot, Gong, LinkedIn

**Steps today**

1. Read the lead's form fill and any email thread
2. Research the firm and the attendees
3. Pick the two or three product areas to show
4. Find a similar customer to reference

**Where it hurts:** Preparation varies by rep. Reference customers are picked from memory.

**Related files:** `sales/leads.csv`, `sales/opportunities.csv`, `customers/customers.csv`, `product/usage_monthly.csv`, `sales/deal_notes.csv`, `marketing/competitor_battlecards.md`

### SAL-4: Quotes and proposals

- **Owner:** Account Executives
- **How often:** Per deal
- **Volume:** About 25 proposals a month
- **Time spent:** about 8 hours a week across the team
- **Systems:** HubSpot, Google Docs, DocuSign

**Steps today**

1. Work out seats, plan and implementation fee
2. Check the internal price list and discount rules
3. Build the proposal document
4. Get discount approval from the Head of Sales
5. Send for signature

**Where it hurts:** Quotes take a day or two, discounts are inconsistent, and the public pricing page is out of date so prospects arrive with the wrong numbers.

**Related files:** `docs/pricing_and_packaging.md`, `sales/opportunities.csv`, `customers/contracts.csv`, `sales/proposals/`, `sales/deal_notes.csv`

### SAL-5: Pipeline review and forecast

- **Owner:** Head of Sales
- **How often:** Weekly
- **Volume:** 40 to 60 open opportunities
- **Time spent:** about 6 hours a week across the team
- **Systems:** HubSpot, Gong, Google Sheets

**Steps today**

1. Each AE updates stages and close dates
2. Sales ops checks for stale or missing fields
3. Head of Sales reviews each deal on a call
4. Commit a forecast for the month and quarter

**Where it hurts:** CRM fields are stale, close dates slip without comment, and the forecast is the Head of Sales' judgment on top of unreliable data.

**Related files:** `sales/opportunities.csv`, `sales/leads.csv`, `sales/deal_notes.csv`

### SAL-6: Win and loss analysis

- **Owner:** Sales Ops Analyst
- **How often:** Quarterly
- **Volume:** About 35 closed deals a month, won and lost
- **Time spent:** about 3 hours a week across the team
- **Systems:** HubSpot, Gong

**Steps today**

1. Export closed opportunities
2. Group by loss reason, segment, source and rep
3. Listen to a sample of call recordings
4. Present findings to sales and marketing

**Where it hurts:** Done rarely and from the loss-reason dropdown alone. Patterns by rep, source and segment go unnoticed.

**Related files:** `sales/opportunities.csv`, `sales/leads.csv`, `marketing/marketing_spend_monthly.csv`, `sales/deal_notes.csv`, `marketing/reviews.csv`, `marketing/competitor_battlecards.md`

## Marketing

### MKT-1: Content production

- **Owner:** Content Marketer
- **How often:** Weekly
- **Volume:** Two blog posts a week, one customer story a month
- **Time spent:** about 24 hours a week across the team
- **Systems:** HubSpot CMS, Google Docs, SEO tool

**Steps today**

1. Pick topics from keyword research and sales questions
2. Interview an internal expert or a customer
3. Draft, edit and add images
4. Publish and distribute by email and social

**Where it hurts:** One writer is the bottleneck. Topics are not tied to what prospects ask or what customers struggle with.

**Related files:** `support/tickets.csv`, `support/help_center_articles.csv`, `sales/leads.csv`, `docs/company_overview.md`, `marketing/blog_posts.csv`

### MKT-2: Channel and campaign performance reporting

- **Owner:** Marketing Ops Specialist
- **How often:** Weekly and monthly
- **Volume:** Seven paid and unpaid channels
- **Time spent:** about 7 hours a week across the team
- **Systems:** HubSpot, Google Ads, LinkedIn Ads, Google Sheets

**Steps today**

1. Export spend from each ad platform
2. Export leads and opportunities from HubSpot
3. Join them in a spreadsheet by channel
4. Work out cost per lead, per opportunity and per customer
5. Recommend budget moves

**Where it hurts:** Reporting stops at cost per lead. Nobody follows a channel through to revenue, so budget stays where the lead count looks good.

**Related files:** `marketing/marketing_spend_monthly.csv`, `marketing/web_funnel_monthly.csv`, `sales/leads.csv`, `sales/opportunities.csv`, `customers/customers.csv`

### MKT-3: Webinar and event follow-up

- **Owner:** Demand Gen Manager
- **How often:** After each event
- **Volume:** One webinar a month, four events a year
- **Time spent:** about 5 hours a week across the team
- **Systems:** HubSpot, Webinar platform

**Steps today**

1. Import the attendee list
2. Split into attended, registered and no-show
3. Write follow-up emails
4. Pass engaged contacts to the SDR

**Where it hurts:** Follow-up goes out days later and is the same email to everyone.

**Related files:** `sales/leads.csv`, `customers/customers.csv`

### MKT-4: Lead nurture

- **Owner:** Demand Gen Manager
- **How often:** Ongoing
- **Volume:** About 4,000 contacts not ready for sales
- **Time spent:** about 4 hours a week across the team
- **Systems:** HubSpot

**Steps today**

1. Segment contacts by industry and size
2. Maintain three email sequences
3. Review open and reply rates monthly
4. Pass re-engaged contacts back to sales

**Where it hurts:** Three generic sequences for every kind of firm. Leads marked 'not now' are rarely looked at again.

**Related files:** `sales/leads.csv`, `sales/opportunities.csv`, `docs/icp.md`, `docs/templates/nurture.md`

### MKT-5: Competitor and review-site monitoring

- **Owner:** VP Marketing
- **How often:** Monthly
- **Volume:** Five competitors, two review sites
- **Time spent:** about 2 hours a week across the team
- **Systems:** Google Docs, Review sites

**Steps today**

1. Check competitor sites and pricing pages
2. Read new reviews of Ledgerline and competitors
3. Update the battlecards
4. Share a summary with sales

**Where it hurts:** Done when someone remembers. Battlecards are a year old.

**Related files:** `sales/opportunities.csv`, `docs/company_overview.md`, `docs/pricing_and_packaging.md`, `marketing/competitor_battlecards.md`, `marketing/reviews.csv`

## Customer Success

### CS-1: New customer onboarding

- **Owner:** Implementation Specialists
- **How often:** Per new customer
- **Volume:** Three to four new customers a month, six weeks each
- **Time spent:** about 30 hours a week across the team
- **Systems:** Ledgerline admin panel, HubSpot, Google Sheets

**Steps today**

1. Kick-off call and data request
2. Import clients, rates and open invoices
3. Configure retainers, milestones and approval rules
4. Connect the accounting integration
5. Train admins and hand over to the account manager

**Where it hurts:** Data imports are manual and slow. Customers that take longest to go live are the ones that use the product least later.

**Related files:** `customers/customers.csv`, `customers/contracts.csv`, `product/usage_monthly.csv`, `support/tickets.csv`

### CS-2: Renewal preparation

- **Owner:** Account Managers
- **How often:** Weekly
- **Volume:** 30 to 40 renewals a month
- **Time spent:** about 12 hours a week across the team
- **Systems:** HubSpot, Zendesk, Ledgerline admin panel

**Steps today**

1. List renewals due in the next 90 days
2. Check usage, open tickets and unpaid invoices for each
3. Decide the renewal offer and any price change
4. Email the customer and book a call for larger accounts
5. Hand agreed terms to finance

**Where it hurts:** Preparation depends on the account manager's memory. Unpaid invoices and open complaints are discovered on the renewal call.

**Related files:** `customers/contracts.csv`, `customers/customers.csv`, `product/usage_monthly.csv`, `support/tickets.csv`, `finance/invoices.csv`, `sales/opportunities.csv`, `docs/templates/renewal.md`

### CS-3: Account health and churn risk

- **Owner:** Head of Customer Success
- **How often:** Monthly
- **Volume:** About 400 accounts across four account managers
- **Time spent:** about 6 hours a week across the team
- **Systems:** HubSpot, Google Sheets

**Steps today**

1. Each account manager marks accounts red, amber or green
2. Review red accounts on a call
3. Agree a save plan for each
4. Report expected churn to finance

**Where it hurts:** Health is a gut call. Most churned customers were marked green the quarter before they left.

**Related files:** `product/usage_monthly.csv`, `customers/contracts.csv`, `customers/customers.csv`, `support/tickets.csv`, `support/nps_responses.csv`, `finance/invoices.csv`

### CS-4: Business review preparation

- **Owner:** Account Managers
- **How often:** Quarterly for larger accounts
- **Volume:** About 60 enterprise accounts, plus requests
- **Time spent:** about 10 hours a week across the team
- **Systems:** Ledgerline admin panel, Zendesk, Google Slides

**Steps today**

1. Pull usage and adoption numbers
2. Summarise support history
3. Build the slide deck
4. Propose next steps and any expansion

**Where it hurts:** Each review takes two to three hours to prepare, so only the largest accounts get one.

**Related files:** `product/usage_monthly.csv`, `support/tickets.csv`, `customers/contracts.csv`, `customers/customers.csv`

### CS-5: Spotting expansion

- **Owner:** Account Managers
- **How often:** Ad hoc
- **Volume:** Expansion on roughly one renewal in four
- **Time spent:** about 3 hours a week across the team
- **Systems:** HubSpot, Ledgerline admin panel

**Steps today**

1. Notice accounts near their seat limit or asking about higher-plan features
2. Raise it on the next call
3. Pass to finance for a new invoice

**Where it hurts:** Found by accident. Accounts using every seat, or asking support about features on a higher plan, are not flagged to anyone.

**Related files:** `product/usage_monthly.csv`, `customers/contracts.csv`, `support/tickets.csv`, `docs/pricing_and_packaging.md`

## Support

### SUP-1: Ticket triage and routing

- **Owner:** Support Agents
- **How often:** Continuous, 8am to 6pm Central on weekdays
- **Volume:** About 270 tickets a month
- **Time spent:** about 15 hours a week across the team
- **Systems:** Zendesk, Slack

**Steps today**

1. Read each new ticket
2. Tag category and priority
3. Check whether the customer is an enterprise account
4. Assign to a generalist, the billing specialist or the technical specialist

**Where it hurts:** A quarter of tickets go to the wrong person first. Enterprise tickets miss their one-hour response about once a week. A quarter of tickets arrive outside working hours.

**Related files:** `support/tickets.csv`, `customers/customers.csv`, `docs/sla_policy.md`

### SUP-2: Answering tickets

- **Owner:** Support Agents
- **How often:** Continuous
- **Volume:** About 270 tickets a month; close to half are how-to questions
- **Time spent:** about 70 hours a week across the team
- **Systems:** Zendesk, Zendesk Guide, Ledgerline admin panel

**Steps today**

1. Find the relevant help article or past ticket
2. Check the customer's account in the admin panel where needed
3. Write the reply
4. Follow up until solved

**Where it hurts:** Most time goes on questions the help centre already answers. Billing questions need the admin panel, which only two people know well.

**Related files:** `support/tickets.csv`, `support/help_center_articles.csv`, `customers/customers.csv`, `docs/sla_policy.md`, `docs/templates/support_macro.md`, `docs/billing_engine_rewrite_2026.md`

### SUP-3: Help centre upkeep

- **Owner:** Head of Support
- **How often:** Ad hoc
- **Volume:** About 120 articles
- **Time spent:** about 2 hours a week across the team
- **Systems:** Zendesk Guide

**Steps today**

1. Notice an article is wrong when a customer complains
2. Rewrite it
3. Ask product to check it

**Where it hurts:** About a third of articles are out of date since the billing engine was rewritten in spring 2026. Nobody knows which.

**Related files:** `support/help_center_articles.csv`, `support/tickets.csv`, `docs/billing_engine_rewrite_2026.md`, `docs/templates/support_macro.md`

### SUP-4: Spotting bugs and incidents

- **Owner:** Technical Support Specialist
- **How often:** Continuous
- **Volume:** 40 to 50 defect reports a month
- **Time spent:** about 6 hours a week across the team
- **Systems:** Zendesk, Jira, Slack

**Steps today**

1. Recognise that a ticket describes a defect
2. Search for similar tickets
3. Raise or update a Jira issue
4. Tell engineering in Slack when several customers are affected
5. Update affected customers when it is fixed

**Where it hurts:** Related reports are worded differently and handled by different agents, so an incident can run for a week before anyone connects it.

**Related files:** `support/tickets.csv`, `customers/customers.csv`

### SUP-5: Satisfaction follow-up

- **Owner:** Head of Support
- **How often:** Weekly
- **Volume:** About 80 CSAT ratings a month, an NPS survey each quarter
- **Time spent:** about 2 hours a week across the team
- **Systems:** Zendesk, HubSpot

**Steps today**

1. Read low ratings and detractor scores
2. Reply to the customer
3. Tell the account manager
4. Report CSAT to the COO

**Where it hurts:** Low scores get a reply days later, and the account manager often hears about it from the customer first.

**Related files:** `support/tickets.csv`, `support/nps_responses.csv`, `customers/customers.csv`, `marketing/reviews.csv`

## Operations

### OPS-1: Weekly company metrics digest

- **Owner:** COO
- **How often:** Weekly
- **Volume:** One digest to the leadership team
- **Time spent:** about 3 hours a week across the team
- **Systems:** Google Docs, Slack, HubSpot, Zendesk, QuickBooks Online

**Steps today**

1. Ask each function head for their numbers
2. Paste them into one document
3. Add a short comment on what changed
4. Send on Monday morning

**Where it hurts:** Arrives late, numbers are a week old, and it says what happened but not why.

**Related files:** `finance/arr_movements_monthly.csv`, `sales/opportunities.csv`, `sales/leads.csv`, `support/tickets.csv`, `finance/ar_aging.csv`

### OPS-2: Customer record clean-up across systems

- **Owner:** Sales Ops Analyst
- **How often:** Ad hoc
- **Volume:** About 400 customers held in HubSpot, Stripe, QuickBooks and Zendesk
- **Time spent:** about 3 hours a week across the team
- **Systems:** HubSpot, Stripe, QuickBooks Online, Zendesk

**Steps today**

1. Find records that disagree on name, contact or plan
2. Decide which system is right
3. Fix the others by hand

**Where it hurts:** The same customer is spelled differently in each system, billing contacts go stale, and nobody trusts a report that joins two systems.

**Related files:** `customers/customers.csv`, `customers/contacts.csv`, `sales/leads.csv`, `finance/payments.csv`, `support/tickets.csv`

### OPS-3: Answering 'what do we know about this customer?'

- **Owner:** Everyone
- **How often:** Many times a day
- **Volume:** Asked before most calls, renewals and escalations
- **Time spent:** about 12 hours a week across the team
- **Systems:** HubSpot, Zendesk, QuickBooks Online, Ledgerline admin panel

**Steps today**

1. Open HubSpot for the contract and owner
2. Open Zendesk for recent tickets
3. Open QuickBooks or ask finance about unpaid invoices
4. Open the admin panel for usage
5. Piece it together

**Where it hurts:** Four systems and ten minutes for a question that should take ten seconds. People skip it, and walk into calls blind.

**Related files:** `customers/customers.csv`, `customers/contracts.csv`, `customers/contacts.csv`, `finance/invoices.csv`, `support/tickets.csv`, `product/usage_monthly.csv`, `support/nps_responses.csv`
