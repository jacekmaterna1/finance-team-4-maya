# Board update: third quarter 2026

Prepared by Alan Brandt and Maya Lindqvist. Figures are at 30 September 2026 unless stated.

## Summary

Growth stayed slow and the business stayed at break-even. ARR ended the quarter at $8,465,928. New business was $157,308 against churn of $129,504. Collections worsened again and are now the main risk to cash. Support response times are slipping as volume grows with a flat team.

## Numbers

| | Q3 2026 |
|---|---|
| ARR at quarter end | $8,465,928 |
| New ARR | $157,308 |
| Expansion ARR | $92,028 |
| Contraction and churn | $168,792 |
| New customers | 12 |
| Customers lost | 7 |
| Revenue | $2,127,257 |
| EBITDA | $113,351 |
| Cash | $2,979,195 |

## What we are worried about

1. **Cash collection.** Overdue receivables have risen for three quarters. Two people handle collections part-time, and one goes on leave in March.
2. **Small-firm churn.** We keep losing the smallest customers within a year or two of signing them.
3. **Speed to lead.** We still take most of a day to answer a demo request.
4. **Support load.** Volume is up, the team is the same size, and we missed the Enterprise response commitment several times this quarter.
5. **Reporting.** This pack took four people most of a week to assemble.

## What we are asking for

Nothing this quarter. We intend to fix these with the team we have.
