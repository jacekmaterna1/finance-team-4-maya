# Tool stack

| Area | Tool | Used for | Owner |
|---|---|---|---|
| CRM and marketing | HubSpot | Forms, contacts, deals, email sequences, meetings | Marketing and Sales |
| Sales | Gong | Call recording | Sales |
| Sales | ZoomInfo, Apollo | Prospect data | Sales |
| Sales | DocuSign | Contracts | Sales |
| Billing | Stripe | Subscriptions, card and ACH payments | Finance |
| Accounting | QuickBooks Online | Ledger, invoices, AR aging | Finance |
| Finance | Expensify | Expenses | Finance |
| Support | Zendesk, Zendesk Guide | Tickets and the help centre | Support |
| Support | Intercom | Website chat | Support |
| Engineering | Jira, GitHub, Sentry, Datadog, AWS | Bugs, code, monitoring, hosting | Product & Engineering |
| Company | Slack, Google Workspace, Notion, Zoom, Loom | Chat, email, docs, calls | Everyone |
| People | Gusto | Payroll | People & Operations |

## Things to know

- There is no data warehouse and no BI tool. Reporting is done in Google Sheets from exports.
- The product's own admin panel holds usage and billing detail for each customer. It has no API that other teams can use; `product/usage_monthly.csv` is a monthly export engineering runs by hand.
- Finance has no access to Zendesk. Support has no access to QuickBooks.
- Clearbit was used to enrich leads until the contract lapsed in June 2026. Nothing has replaced it.
- A website chatbot (Drift) ran from January to September 2024 and was switched off. A collections automation tool (Paidly) ran for six weeks in 2025 and was switched off.
- Every tool's cost is in `finance/vendor_bills.csv`.
