# Ledgerline: company overview

Ledgerline is a fictional company. Every customer, person and number in this data room was invented for the Scaleworks AI Operator Challenge.

## What it sells

Billing and subscription software for professional services firms: consultancies, law firms, architects, agencies, engineering and accounting practices. Firms use it to invoice clients, run retainers and milestone billing, collect payments, and give clients a portal. It connects to QuickBooks Online and Xero.

## Shape of the business at 2026-10-31

| | |
|---|---|
| ARR | $8,529,288 |
| ARR growth, year on year | 5.7% |
| Customers | 396 |
| Average contract value | $21,539 |
| Net revenue retention, trailing 12 months | 97.0% |
| Gross revenue retention, trailing 12 months | 93.1% |
| Revenue, trailing 12 months | $8,407,282 |
| EBITDA, trailing 12 months | $296,960 (3.5%) |
| Gross margin | 78.9% |
| Cash | $2,992,481 |
| Staff | 46 |

Founded in 2018, based in Austin, Texas, with most of the team remote in the US and a small group in London. About three quarters of customers are in the US, the rest in the UK and Canada. The company grew quickly to 2023, then slowed. It runs at roughly break-even and is owned by a private investor that expects it to stay that way while growth is rebuilt.

## Customers

Three plans, sold per seat on annual contracts. See `pricing_and_packaging.md`.

- **Core**: small firms, 9 to 18 seats, often paying monthly by card.
- **Growth**: the main plan, 13 to 30 seats.
- **Enterprise**: 57 accounts, 22 seats and up, with a one-hour support commitment.

## How it goes to market

Inbound first. About 314 leads a month come through the website forms, events and outbound. One sales development rep qualifies every form fill by hand. Four account executives close: two on firms under 200 staff, two on firms of 200 and over. Four account managers own renewals. The trailing 12-month win rate on new business is 24%.

## The team

46 people. See `org_chart.md` and `people/employees.csv`.

## What is in this data room

See `README.md` at the top level for every file and how they join.
