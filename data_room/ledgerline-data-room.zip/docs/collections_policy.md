# Collections policy

- Invoices are due 30 days from issue. Card customers are charged on the invoice date.
- Reminders: a courtesy note 5 days before the due date, then at 7, 21 and 45 days past due.
- No message may threaten suspension or legal action without the VP Finance's sign-off. The CEO reads complaints about collections personally.
- Nothing goes to one of the 50 largest accounts without a person reading it first.
- Do not chase an invoice the customer has disputed, or a customer with an open support escalation, until the account manager says so. Tell the account manager before finance contacts one of their accounts.
- Payment plans: the VP Finance can approve up to 90 days. Longer needs the CFO role, currently held by the CEO.
- Write-offs: the VP Finance can approve up to $2,000. Card invoices unpaid after 150 days are written off automatically.
- Cash application: bank transfers and cheques are matched to invoices by hand and can take three to five working days to show as paid.
