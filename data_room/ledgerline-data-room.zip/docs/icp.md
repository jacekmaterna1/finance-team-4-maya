# Ideal customer profile

Last updated: April 2025.

## Who we sell to

Professional services firms that bill clients for time, retainers or project milestones.

- **Industries**: consultancies, law firms, architecture practices, agencies, engineering consultancies, accounting firms.
- **Size**: 10 to 1,000 staff.
- **Geography**: United States, United Kingdom, Canada.
- **Buyer**: finance director, practice manager, operations lead or managing partner.

## Signs of a good fit

- Bills by retainer or milestone, not only by the hour.
- Uses QuickBooks Online or Xero.
- Has outgrown invoicing from spreadsheets or from the accounting package.

## Not a fit

- Product companies and retailers.
- Sole practitioners.
- Firms that need full practice management or time tracking as the main product.
