# Lead nurture sequences

The templates Marketing uses today, copied from the template library as they are.

## General sequence, email 1

*Jess (marketing), 2023*

**Subject:** Getting paid shouldn't take this long

Hi {{first_name}},

Thanks for downloading our guide. Most firms we talk to have the same problem: the work gets done, but the invoice goes out late, sits in someone's inbox, and the money arrives 60 days later.

Ledgerline is billing software built for professional services firms. You can send invoices, take card and bank payments, and give clients a portal where they can see what they owe. It syncs with QuickBooks Online and Xero, so your books stay up to date.

Over the next couple of weeks I'll send a few short notes on how firms like {{company}} speed up their billing.

Best,
The Ledgerline Team

---

## General sequence, email 2

*Jess, 2023*

**Subject:** 3 ways firms cut days off their billing cycle

Hi {{first_name}},

Here are three things we see working for firms like {{company}}:

1. Invoice the same week the work is done. Waiting for month end adds days for no reason.
2. Make it easy to pay. Clients pay faster when there's a card or bank transfer link right on the invoice.
3. Give clients a portal. Fewer "can you resend that invoice?" emails.

Ledgerline does all three out of the box. Want to see how? Book a 20-minute demo: {{demo_link}}

Best,
The Ledgerline Team

---

## General sequence, email 3

*Jess, 2023. P.S. added by Dev, Mar 2024*

**Subject:** Still thinking it over?

Hi {{first_name}},

I wanted to check in one more time. If billing is taking up more of your team's week than it should, Ledgerline can help.

Firms using Ledgerline send invoices faster, get paid sooner, and spend less time reconciling payments in QuickBooks Online or Xero.

If now isn't the right time, no problem. But if you'd like to see it in action, you can grab a time here: {{demo_link}}

Best,
The Ledgerline Team

P.S. Plans start at $47 per user per month.

---

## Law firms sequence, email 1

*Cloned from General by Jess, 2023*

**Subject:** Getting paid shouldn't take this long

Hi {{first_name}},

Thanks for downloading our guide. Most law firms we talk to have the same problem: the work gets done, but the invoice goes out late, sits in someone's inbox, and the money arrives 60 days later.

Ledgerline is billing software built for law firms and other professional services firms. You can send invoices, take card and bank payments, and give clients a portal where they can see what they owe. It syncs with QuickBooks Online and Xero, so your books stay up to date.

Over the next couple of weeks I'll send a few short notes on how firms like {{company}} speed up their billing.

Best,
The Ledgerline Team

---

## Law firms sequence, email 2

*Cloned from General by Jess, 2023*

**Subject:** 3 ways law firms cut days off their billing cycle

Hi {{first_name}},

Here are three things we see working for law firms like {{company}}:

1. Bill the same week the work is done. Waiting for month end adds days for no reason.
2. Make it easy to pay. Clients pay faster when there's a card or bank transfer link right on the invoice.
3. Give clients a portal. Fewer "can you resend that bill?" emails.

Ledgerline does all three out of the box. Want to see how? Book a 20-minute demo: {{demo_link}}

Best,
The Ledgerline Team

---

## Law firms sequence, email 3

*Cloned from General by Jess, 2023. Todo: add retainer angle*

**Subject:** Still thinking it over?

Hi {{first_name}},

I wanted to check in one more time. If billing is taking up more of your firm's week than it should, Ledgerline can help.

Law firms using Ledgerline send invoices faster, get paid sooner, and spend less time reconciling payments in QuickBooks Online or Xero.

If now isn't the right time, no problem. But if you'd like to see it in action, you can grab a time here: {{demo_link}}

Best,
The Ledgerline Team

P.S. Plans start at $47 per user per month.

---

## Agencies sequence, email 1

*Cloned from General, Jess, 2023*

**Subject:** Getting paid shouldn't take this long

Hi {{first_name}},

Thanks for downloading our guide. Most agencies we talk to have the same problem: the project gets delivered, but the invoice goes out late, sits in someone's inbox, and the money arrives 60 days later.

Ledgerline is billing software built for agencies and other professional services firms. You can send invoices, take card and bank payments, and give clients a portal where they can see what they owe. It syncs with QuickBooks Online and Xero, so your books stay up to date.

Over the next couple of weeks I'll send a few short notes on how agencies like {{company}} speed up their billing.

Best,
The Ledgerline Team

---

## Agencies sequence, email 2

*Cloned from General, Jess, 2023*

**Subject:** 3 ways agencies cut days off their billing cycle

Hi {{first_name}},

Here are three things we see working for agencies like {{company}}:

1. Invoice the same week the project milestone is hit. Waiting for month end adds days for no reason.
2. Make it easy to pay. Clients pay faster when there's a card or bank transfer link right on the invoice.
3. Give clients a portal. Fewer "can you resend that invoice?" emails.

Ledgerline does all three out of the box. Want to see how? Book a 20-minute demo: {{demo_link}}

Best,
The Ledgerline Team

---

## Agencies sequence, email 3

*Cloned from General, Jess, 2023*

**Subject:** Still thinking it over?

Hi {{first_name}},

I wanted to check in one more time. If billing is taking up more of your agency's week than it should, Ledgerline can help.

Agencies using Ledgerline send invoices faster, get paid sooner, and spend less time reconciling payments in QuickBooks Online or Xero.

If now isn't the right time, no problem. But if you'd like to see it in action, you can grab a time here: {{demo_link}}

Best,
The Ledgerline Team

P.S. Plans start at $47 per user per month.
