# Collections reminders

The templates Finance uses today, copied from the template library as they are.

## Courtesy reminder, 5 days before due

*Marisol (finance), Jan 2024, fine as is*

**Subject:** Ledgerline invoice {{invoice_number}} due {{due_date}}

Hi {{first_name}},

A quick heads-up that invoice {{invoice_number}} for {{amount}} is due on {{due_date}}.

If {{company}} pays by card on file, there's nothing you need to do. We'll charge it on the due date. If you pay by bank transfer, our remittance details are on the invoice and under Settings > Billing.

If anything looks off, like the seat count, plan or billing contact, just reply here before the due date and we'll fix it rather than have you pay the wrong amount.

Thanks,
Ledgerline Billing
billing@ledgerline.com

---

## First reminder, 7 days past due

*Copied from old AR tool defaults, 2021, never rewritten*

**Subject:** Overdue: invoice {{invoice_number}}

Dear {{first_name}},

Our records indicate that invoice {{invoice_number}} in the amount of {{amount}}, which was due on {{due_date}}, remains outstanding.

We kindly request that payment be remitted at your earliest convenience. Payment may be made by card or bank transfer via the link on the invoice.

Should payment have already been sent, please disregard this notice and accept our thanks. If there is a query regarding the invoice, please contact the Billing team at billing@ledgerline.com.

Regards,
Accounts Receivable
Ledgerline, Inc.

---

## Second reminder, 21 days past due

*Marisol, rewritten Sept 2024 after the AR policy refresh*

**Subject:** Invoice {{invoice_number}} is now 21 days overdue

Hi {{first_name}},

I'm following up on invoice {{invoice_number}} for {{amount}}, which was due on {{due_date}} and is still unpaid.

I know these sometimes get stuck in an approval queue or go to someone who's left. If that's what happened, let me know who should be getting our invoices and I'll update the billing contact for {{company}}.

If there's a problem with the invoice itself, or you need to split the payment, reply and we can work something out. Otherwise, you can pay here: {{payment_link}}

Thanks,
{{sender_name}}
Ledgerline Billing

---

## Final reminder, 45 days past due

*Greg, Aug 2022, written while covering AR during the cash crunch*

**Subject:** FINAL NOTICE: account suspension - invoice {{invoice_number}}

{{first_name}},

Invoice {{invoice_number}} for {{amount}} is now 45 days past due. We have contacted you several times without a response.

If full payment is not received within 5 business days, we will suspend access to Ledgerline for all users at {{company}}, including your client portal, and refer the balance to a third-party collections agency. Any costs of collection will be added to your balance.

We would prefer not to take these steps, but continued non-payment leaves us no choice.

Pay now: {{payment_link}}

Ledgerline Accounts Receivable
