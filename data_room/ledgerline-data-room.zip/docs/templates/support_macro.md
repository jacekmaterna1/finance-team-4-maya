# Support macros

The templates Support uses today, copied from the template library as they are.

## Password reset

*Support team, 2023, SSO line added by Hana Jun 2024*

**Subject:** Resetting your Ledgerline password

Hi {{first_name}},

You can reset your password from the login page: click "Forgot password" and enter the email address you use for Ledgerline. The reset link is valid for 60 minutes.

If the email doesn't arrive within a few minutes, check your spam folder. Some firms' email filters hold messages from new senders.

If your firm uses single sign-on, you won't be able to reset your password in Ledgerline. Please contact your IT team instead.

Let us know if you're still stuck.

{{agent_name}}
Ledgerline Support

---

## How proration works

*Hana, Nov 2024*

**Subject:** Re: charge for added seats

Hi {{first_name}},

Good question. When you add seats partway through your billing period, we only charge for the days remaining.

Here's how it's calculated: we take the monthly seat price, divide it by 30 to get a daily rate, and multiply that by the number of days left until your next billing date. Every month is treated as 30 days, so the daily rate is the same whether it's February or March.

So, for example, a Growth seat ($68) added with 15 days left would be charged at $34.

Removing seats takes effect at your next renewal. We don't issue partial refunds mid-term.

Hope that helps,
{{agent_name}}
Ledgerline Support

---

## Card payment failed

*Hana and Marisol, Aug 2024*

**Subject:** Your Ledgerline payment didn't go through

Hi {{first_name}},

We tried to charge the card on file for {{company}} for invoice {{invoice_number}} ({{amount}}), but the payment was declined.

This is usually an expired card, a changed billing address, or the bank blocking the charge. You can update your card under Settings > Billing.

We'll automatically try the card once more in 3 days. If that retry also fails, the invoice will be marked overdue and our billing team will be in touch.

If you'd rather pay by bank transfer this time, reply and we'll send the details.

{{agent_name}}
Ledgerline Support

---

## Bug acknowledged, passed to engineering

*Hana, May 2025. Delete the workaround line if there isn't one*

**Subject:** Re: {{ticket_subject}}

Hi {{first_name}},

Thanks for the detail. That made it much easier to reproduce. I can confirm this is a bug on our end and not something you're doing wrong.

I've logged it with our engineering team (reference {{bug_id}}). I can't give you a fix date yet, as it depends on what else is in the current sprint, but I'll update this ticket when there's news, and I'll check in at least once a week either way.

In the meantime, {{workaround}}

Sorry for the hassle.

{{agent_name}}
Ledgerline Support
