# Renewal emails

The templates Customer Success uses today, copied from the template library as they are.

## Renewal notice, 60 days out

*CS team (Omar), Feb 2025*

**Subject:** Your Ledgerline renewal on {{renewal_date}}

Hi {{first_name}},

Your Ledgerline subscription for {{company}} renews on {{renewal_date}}.

Here's what's on your current contract:
- Plan: {{plan}}
- Seats: {{seat_count}}
- Annual total: {{amount}}

If you want to change your seat count or move plans, now is a good time. Changes need to be in at least 30 days before renewal so we can update your invoice.

If everything looks right, you don't need to do anything. We'll send the renewal invoice about two weeks before {{renewal_date}}.

Any questions, reply here or grab time with me: {{calendar_link}}

Thanks,
{{account_manager}}

---

## Price change at renewal

*Omar + finance, drafted for 2024 price increase, reused since*

**Subject:** Important information about your Ledgerline pricing

Dear {{first_name}},

We are writing to inform you that, effective with your renewal on {{renewal_date}}, the price of your {{plan}} plan will change from {{old_price}} to {{new_price}} per seat per month.

This adjustment reflects our continued investment in the platform, including new features, improved reliability and expanded integrations.

Based on your current seat count of {{seat_count}}, your new annual total will be {{amount}}.

We value your partnership and are committed to delivering ongoing value to {{company}}. If you have any questions, please contact your account manager.

Sincerely,
The Ledgerline Team
