# Sales development replies

The templates Sales uses today, copied from the template library as they are.

## Reply to demo request

*Dev (SDR lead), Oct 2024*

**Subject:** Your Ledgerline demo

Hi {{first_name}},

Thanks for reaching out. I'm {{sender_name}}, and I'll be setting up your demo.

Before we meet, it would help to know a couple of things so I can show you the right parts of the product rather than a generic tour:

- Roughly how many people at {{company}} would use Ledgerline?
- How do you bill today? Hourly, fixed fee, retainers, milestones, or a mix?
- Are you on QuickBooks Online, Xero or something else?

Here's my calendar for a 30-minute slot this week or next: {{calendar_link}}

Talk soon,
{{sender_name}}
Ledgerline

---

## Not a fit right now

*Ryan, 2022. Reps edit this a lot before sending*

**Subject:** Re: Ledgerline demo request

Hi {{first_name}},

Thanks for your interest in Ledgerline. Based on what you've told us, {{company}} is probably too small for us at the moment. Our customers are typically firms with 10 or more billing staff, and honestly a spreadsheet or your accounting software's built-in invoicing is likely all you need for now.

We don't want to waste your time, or ours, on a demo that isn't going to go anywhere.

If your firm grows, feel free to get back in touch.

All the best,
{{sender_name}}

---

## Existing customer used the sales form

*Dev, Mar 2025, after the HubSpot routing fix*

**Subject:** Re: your message to Ledgerline

Hi {{first_name}},

Thanks for getting in touch. It looks like {{company}} is already a Ledgerline customer, so I've passed your note to the right people instead of booking a sales call.

If it's a product or how-to question, our support team will reply from support@ledgerline.com, usually within one business day. If it's about adding seats, changing plans or your contract, your account manager {{account_manager}} will be in touch.

If I've got that wrong and you're asking about a new entity or a separate firm, just reply and let me know.

Thanks,
{{sender_name}}
