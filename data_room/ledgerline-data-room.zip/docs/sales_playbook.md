# Sales playbook: inbound handling and routing

## Inbound

1. Every website form fill creates a lead in HubSpot and posts to the #inbound-leads Slack channel.
2. Jules (SDR) reviews each lead, checks the company, and either replies to book a call, moves it to nurture, or disqualifies it.
3. Jules works 8am to 5pm Central, Monday to Friday.
4. Qualified leads are assigned by company size: under 200 staff to Nick or Leila, 200 and over to Owen or Grace.
5. Meetings are booked through HubSpot Meetings onto the account executive's calendar. Renata (Head of Sales) must approve any change to what is allowed to book onto those calendars.

## Do not

- Do not send a sales reply to an existing customer. Pass them to their account manager or to support.
- Do not quote prices or promise a discount by email. The public pricing page is out of date; quotes come from the internal price list.
- Do not book meetings for students, vendors or competitors.

## Stages

Discovery, Demo done, Proposal sent, Negotiation, Closed won or Closed lost. Every lost deal needs a loss reason.

## Targets

Marketing is measured on sales-accepted meetings: target 45 a month.
