# Org chart at 2026-10-31

Alan Brandt (CEO) has Finance and Product & Engineering reporting to him. Maya Lindqvist (COO) has Sales, Marketing, Customer Success, Support and People & Operations.

### Executive

- Alan Brandt, Chief Executive Officer
- Maya Lindqvist, Chief Operating Officer

### Finance

- Priya Nair, AR Specialist
- Dana Ruiz, VP Finance
- Marcus Bell, Staff Accountant
- Ravi Quill, FP&A Analyst

### Sales

- Owen Castellano, Account Executive
- Renata Kowalczyk, Head of Sales
- Grace Mbeki, Account Executive
- Jules Tan, Sales Development Rep
- Nick Ferraro, Account Executive
- Leila Haddad, Account Executive
- Dalia Sterling, Sales Ops Analyst

### Marketing

- Emma Eastman, Demand Gen Manager
- Tom Okafor, VP Marketing
- Noah Yardley, Content Marketer
- Nico Abbott, Marketing Ops Specialist

### Customer Success

- Lucia Bell, Implementation Specialist
- Nadia Sinclair, Account Manager
- Daniel Banerjee, Head of Customer Success
- Nadia Upton, Account Manager
- Maria Yardley, Account Manager
- Hannah Drummond, Account Manager
- Renee Nakamura, Implementation Specialist

### Support

- Sam Whitfield, Head of Support
- Dev Malhotra, Technical Support Specialist
- Ana Duarte, Billing Support Specialist
- Harriet Hume, Support Agent
- Ethan Finch, Support Agent
- Nico Thackeray, Support Agent

### Product & Engineering

- Noah Stanhope, Engineer
- Rhys Devlin, Engineer
- Samuel Nakamura, Senior Engineer
- Oscar Lindqvist, Product Manager
- Ravi Mercer, Chief Technology Officer
- Jonas Rosales, Product Manager
- Maria Calloway, Engineering Manager
- Leo Achebe, QA Engineer
- Tomas Underhill, DevOps Engineer
- Quentin Yates, Engineer
- Pablo Tan, Senior Engineer
- Ravi Glover, Engineer
- Victor Malhotra, Senior Engineer
- Elena Ellery, Product Designer

### People & Operations

- Odette Whitlock, People Operations Manager
- Oscar Mbeki, IT & Office Coordinator
